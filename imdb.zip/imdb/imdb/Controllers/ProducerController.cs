﻿using imdb.Models;
using System.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;

namespace imdb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProducerController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public ProducerController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [HttpGet]
        public JsonResult Get()
        {
            string query = @"
             select pro_id,pro_name,pro_phone,pro_company from producer
              ";
            DataTable dataTable = new DataTable();
            string datasource = _configuration.GetConnectionString("defualtconnection");
            MySqlDataReader reader;
            using (MySqlConnection mycon = new MySqlConnection(datasource))
            {
                mycon.Open();
                using (MySqlCommand mycommand = new MySqlCommand(query, mycon))
                {
                    reader = mycommand.ExecuteReader();
                    dataTable.Load(reader);

                    reader.Close();
                    mycon.Close();
                }

            }

            return new JsonResult(dataTable);


        }
        [HttpPost]
        public JsonResult Post(producer pro)
        {
            string query = @"
             insert into producer (pro_id,pro_name,pro_phone,pro_company) values (@pro_id,@pro_name,@pro_phone,@pro_company);
              ";
            DataTable dataTable = new DataTable();
            string datasource = _configuration.GetConnectionString("defualtconnection");
            MySqlDataReader reader;
            using (MySqlConnection mycon = new MySqlConnection(datasource))
            {
                mycon.Open();
                using (MySqlCommand mycommand = new MySqlCommand(query, mycon))
                {
                    mycommand.Parameters.AddWithValue("@pro_id", pro.pro_id);
                    mycommand.Parameters.AddWithValue("@pro_name", pro.pro_name);
                    mycommand.Parameters.AddWithValue("@pro_phone", pro.pro_phone);
                    mycommand.Parameters.AddWithValue("@pro_company", pro.pro_company);
                    reader = mycommand.ExecuteReader();
                    dataTable.Load(reader);

                    reader.Close();
                    mycon.Close();
                }

            }

            return new JsonResult("Added successsfully");


        }


        [HttpPut]
        public JsonResult Put(producer pro)
        {
            string query = @"
            update producer set 
            pro_name = @pro_name,
            pro_phone = @pro_phone,
            pro_company = @pro_company where pro_id = @pro_id
            ";

            DataTable dataTable = new DataTable();
            string datasource = _configuration.GetConnectionString("defualtconnection");
            MySqlDataReader reader;
            using (MySqlConnection mycon = new MySqlConnection(datasource))
            {
                mycon.Open();
                using (MySqlCommand mycommand = new MySqlCommand(query, mycon))
                {
                    mycommand.Parameters.AddWithValue("@pro_id", pro.pro_id);
                    mycommand.Parameters.AddWithValue("@pro_name", pro.pro_name);
                    mycommand.Parameters.AddWithValue("@pro_phone", pro.pro_phone);
                    mycommand.Parameters.AddWithValue("@pro_company", pro.pro_company);
                    reader = mycommand.ExecuteReader();
                    dataTable.Load(reader);

                    reader.Close();
                    mycon.Close();
                }

            }

            return new JsonResult("updated successsfully");


        }

        [HttpDelete("{id}")]
        public JsonResult Delete(int id)
        {
            string query = @"
            delete from producer where pro_id = @pro_id
            ";

            DataTable dataTable = new DataTable();
            string datasource = _configuration.GetConnectionString("defualtconnection");
            MySqlDataReader reader;
            using (MySqlConnection mycon = new MySqlConnection(datasource))
            {
                mycon.Open();
                using (MySqlCommand mycommand = new MySqlCommand(query, mycon))
                {
                    mycommand.Parameters.AddWithValue("@pro_id", id);
                    reader = mycommand.ExecuteReader();
                    dataTable.Load(reader);

                    reader.Close();
                    mycon.Close();
                }

            }

            return new JsonResult("Deleted successsfully");


        }
    }

}
