﻿using System.Data;
using imdb.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Common;
using MySqlX.XDevAPI.Relational;

namespace imdb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ActorController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public ActorController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [HttpGet]
        public JsonResult Get()
        {
            string query = @"
             select act_id,act_name,act_bio,act_gender from actor
              ";
            DataTable dataTable = new DataTable();
            string datasource = _configuration.GetConnectionString("defualtconnection");
            MySqlDataReader reader;
            using (MySqlConnection mycon = new MySqlConnection(datasource))
            {
                mycon.Open();
                using (MySqlCommand mycommand = new MySqlCommand(query, mycon))
                {
                    reader = mycommand.ExecuteReader();
                    dataTable.Load(reader);

                    reader.Close();
                    mycon.Close();
                }

            }

            return new JsonResult(dataTable);


        }
        [HttpPost]
        public JsonResult Post(actor act)
        {
            string query = @"
             insert into actor (act_id,act_name,act_bio,act_gender) values (@act_id,@act_name,@act_bio,@act_gender);
              ";
            DataTable dataTable = new DataTable();
            string datasource = _configuration.GetConnectionString("defualtconnection");
            MySqlDataReader reader;
            using (MySqlConnection mycon = new MySqlConnection(datasource))
            {
                mycon.Open();
                using (MySqlCommand mycommand = new MySqlCommand(query, mycon))
                {
                    mycommand.Parameters.AddWithValue("@act_id", act.act_id);
                    mycommand.Parameters.AddWithValue("@act_name", act.act_name);
                    mycommand.Parameters.AddWithValue("@act_bio", act.act_bio);
                    mycommand.Parameters.AddWithValue("@act_gender", act.act_gender);
                    reader = mycommand.ExecuteReader();
                    dataTable.Load(reader);

                    reader.Close();
                    mycon.Close();
                }

            }

            return new JsonResult("Added successsfully");


        }


        [HttpPut]
        public JsonResult Put(actor act)
        {
            string query = @"
            update actor set 
            act_name = @act_name,
            act_bio = @act_bio,
            act_gender = @act_gender where act_id = @act_id
            ";

            DataTable dataTable = new DataTable();
            string datasource = _configuration.GetConnectionString("defualtconnection");
            MySqlDataReader reader;
            using (MySqlConnection mycon = new MySqlConnection(datasource))
            {
                mycon.Open();
                using (MySqlCommand mycommand = new MySqlCommand(query, mycon))
                {
                    mycommand.Parameters.AddWithValue("@act_id", act.act_id);
                    mycommand.Parameters.AddWithValue("@act_name", act.act_name);
                    mycommand.Parameters.AddWithValue("@act_bio", act.act_bio);
                    mycommand.Parameters.AddWithValue("@act_gender", act.act_gender);
                    reader = mycommand.ExecuteReader();
                    dataTable.Load(reader);

                    reader.Close();
                    mycon.Close();
                }

            }

            return new JsonResult("updated successsfully");


        }

        [HttpDelete("{id}")]
        public JsonResult Delete(int id)
        {
            string query = @"
            delete from actor where act_id = @act_id
            ";

            DataTable dataTable = new DataTable();
            string datasource = _configuration.GetConnectionString("defualtconnection");
            MySqlDataReader reader;
            using (MySqlConnection mycon = new MySqlConnection(datasource))
            {
                mycon.Open();
                using (MySqlCommand mycommand = new MySqlCommand(query, mycon))
                {
                    mycommand.Parameters.AddWithValue("@act_id", id);
                    reader = mycommand.ExecuteReader();
                    dataTable.Load(reader);

                    reader.Close();
                    mycon.Close();
                }

            }

            return new JsonResult("Deleted successsfully");


        }
    }

}
