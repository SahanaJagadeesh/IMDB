﻿using imdb.Models;
using System.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;

namespace imdb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public MovieController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [HttpGet]
        public JsonResult Get()
        {
            string query = @"
             select mov_id,mov_title,mov_year,pro_id,act_id from movies
              ";
//            string query = @"
//               CALL GetMovies();
//";
            DataTable dataTable = new DataTable();
            string datasource = _configuration.GetConnectionString("defualtconnection");
            MySqlDataReader reader;
            using (MySqlConnection mycon = new MySqlConnection(datasource))
            {
                mycon.Open();
                using (MySqlCommand mycommand = new MySqlCommand(query, mycon))
                {
                    reader = mycommand.ExecuteReader();
                    dataTable.Load(reader);

                    reader.Close();
                    mycon.Close();
                }

            }

            return new JsonResult(dataTable);


        }
        [HttpPost]
        public JsonResult Post(movie mov)
        {
            string query = @"
             insert into movies (mov_id,mov_title,mov_year,pro_id,act_id) values (@mov_id,@mov_title,@mov_year,@pro_id,@act_id);
              ";
            DataTable dataTable = new DataTable();
            string datasource = _configuration.GetConnectionString("defualtconnection");
            MySqlDataReader reader;
            using (MySqlConnection mycon = new MySqlConnection(datasource))
            {
                mycon.Open();
                using (MySqlCommand mycommand = new MySqlCommand(query, mycon))
                {
                    mycommand.Parameters.AddWithValue("@mov_id", mov.mov_id);
                    mycommand.Parameters.AddWithValue("@mov_title", mov.mov_title);
                    mycommand.Parameters.AddWithValue("@mov_year", mov.mov_year);
                    mycommand.Parameters.AddWithValue("@pro_id", mov.pro_id);
                    mycommand.Parameters.AddWithValue("@act_id", mov.act_id);
                    reader = mycommand.ExecuteReader();
                    dataTable.Load(reader);

                    reader.Close();
                    mycon.Close();
                }

            }

            return new JsonResult("Added successsfully");


        }


        [HttpPut]
        public JsonResult Put(movie mov)
        {
            string query = @"
            update movies set 
            mov_title = @mov_title,
            mov_year = @mov_year,
            pro_id = @pro_id, 
            act_id = @act_id where mov_id = @mov_id
            ";

            DataTable dataTable = new DataTable();
            string datasource = _configuration.GetConnectionString("defualtconnection");
            MySqlDataReader reader;
            using (MySqlConnection mycon = new MySqlConnection(datasource))
            {
                mycon.Open();
                using (MySqlCommand mycommand = new MySqlCommand(query, mycon))
                {
                    mycommand.Parameters.AddWithValue("@mov_id", mov.mov_id);
                    mycommand.Parameters.AddWithValue("@mov_title", mov.mov_title);
                    mycommand.Parameters.AddWithValue("@mov_year", mov.mov_year);
                    mycommand.Parameters.AddWithValue("@pro_id", mov.pro_id);
                    mycommand.Parameters.AddWithValue("@act_id", mov.act_id);
                    reader = mycommand.ExecuteReader();
                    dataTable.Load(reader);

                    reader.Close();
                    mycon.Close();
                }

            }

            return new JsonResult("updated successsfully");


        }

        [HttpDelete("{id}")]
        public JsonResult Delete(int id)
        {
            string query = @"
            delete from movies where mov_id = @mov_id
            ";

            DataTable dataTable = new DataTable();
            string datasource = _configuration.GetConnectionString("defualtconnection");
            MySqlDataReader reader;
            using (MySqlConnection mycon = new MySqlConnection(datasource))
            {
                mycon.Open();
                using (MySqlCommand mycommand = new MySqlCommand(query, mycon))
                {
                    mycommand.Parameters.AddWithValue("@mov_id", id);
                    reader = mycommand.ExecuteReader();
                    dataTable.Load(reader);

                    reader.Close();
                    mycon.Close();
                }

            }

            return new JsonResult("Deleted successsfully");


        }
    }
}
