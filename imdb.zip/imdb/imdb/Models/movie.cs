﻿namespace imdb.Models
{
    public class movie
    {
        public int mov_id { get; set; }
        public string mov_title { get; set; }
        public int mov_year { get; set; }
        public int pro_id { get; set; }
        public int act_id { get; set; }

    }
}
