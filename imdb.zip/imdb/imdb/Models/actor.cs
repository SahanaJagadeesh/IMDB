﻿namespace imdb.Models
{
    public class actor
    {
        public int act_id { get; set; }
        public string act_name { get; set; }

        public string act_bio { get; set; }

        public string act_gender { get; set; }
    }
}
