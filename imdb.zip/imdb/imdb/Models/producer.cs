﻿namespace imdb.Models
{
    public class producer
    {
        public int pro_id { get; set; }
        public string pro_name { get; set; }
        public string pro_phone { get; set; }
        public string pro_company { get; set; }
    }
}
